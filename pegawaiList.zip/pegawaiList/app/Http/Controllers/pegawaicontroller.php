<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pegawais; 


class Pegawaicontroller extends Controller
{
    public function tampilkanData()
    {

        $dataPegawai = Pegawais::all();
        return view('pegawai ', ['dataPegawai' => $dataPegawai]);
    }

    public function store(Request $request)
    {
        // Validasi form jika diperlukan
        // $validatedData = $request->validate([
        //     'name' => 'required',
        //     'posisi' => 'required',
        //     'gaji' => 'required|numeric',
        // ]);

        // Simpan data ke database
        Pegawais::create([
            'name' => $request->input('name'),
            'posisi' => $request->input('posisi'),
            'gaji' => $request->input('gaji'),
        ]);

        return redirect('/pegawai');
    }

    public function update($id){
         // Mendapatkan data pegawai berdasarkan ID
         $pegawaii = Pegawais::find($id);

         // Menampilkan halaman update dengan data pegawai yang akan diupdate
         return view('update', compact('pegawaii'));
    }

    public function edit(Request $request, $id){
        // Mendapatkan data pegawai berdasarkan ID
        $pegawaii = Pegawais::find($id);
        $pegawaii -> name = $request ->input('name');
        $pegawaii -> posisi = $request ->input('posisi');
        $pegawaii -> gaji = $request ->input('gaji');
        $pegawaii -> save();
        
        return redirect('/pegawai')->with('status',"Data Berhasil Di Update");
   }
}

;<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Hello, world!</title>
  </head>
  <body>
    



    <div class="container px-4">
        <div class="row gx-5">
          <div class="col">
            <h1>Data Pegawai</h1>
            <table class="table">
                <thead>
                  <tr>
                    <th scope="col">NAMA</th>
                    <th scope="col">Posisi</th>
                    <th scope="col">Gaji</th>
                    <th scope="col">Action</th>
                   
                  </tr>
                </thead>
                <tbody>
                
                  <?php $__currentLoopData = $dataPegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pegawai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                      <td><?php echo e($pegawai->name); ?></td>
                      <td><?php echo e($pegawai->posisi); ?></td>
                      <td><?php echo e($pegawai->gaji); ?></td>
                      <td> <a href="<?php echo e(url('/update/'.$pegawai->id)); ?>"><button type="button" class="btn btn-primary">Update</button></a></td>
                  </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            
          </div>
      </div>

      <div class="container px-4">
        <h1>Insert Data</h1>
        <div class="row gx-5">
          <div class="col">
            <form action="/pegawai" method="POST">
                <?php echo csrf_field(); ?>
                
                <div class="mb-3">
                  <label for="exampleInputnama" class="form-label">Nama</label>
                  <input type="text" class="form-control" name="name">
                  
                </div>
                <div class="mb-3">  
                    <label for="exampleInputnama" class="form-label">Posisi</label>
                    <input type="text" class="form-control" name="posisi">
                    
                  </div>
                  <div class="mb-3">
                    <label for="exampleInputnama" class="form-label">Gaji</label>
                    <input type="text" class="form-control" name="gaji">
                    
                  </div>

                
               
                <button type="submit" class="btn btn-primary">insertData</button>
              </form>
          </div>
        
        </div>
      </div>




    



 
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

   
  </body>
</html>

<?php /**PATH C:\Users\ASUS\pegawaiList\resources\views/pegawai.blade.php ENDPATH**/ ?>